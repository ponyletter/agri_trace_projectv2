package controller

import (
	"agri-trace/model"
	"agri-trace/pkg/blockchain"
	"agri-trace/pkg/ipfs"
	"database/sql"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

// TraceController 溯源核心控制器
type TraceController struct {
	DB               *gorm.DB
	BlockchainClient blockchain.Client
	IPFSClient       ipfs.Client
}

// ==================== 仪表盘大屏 ====================

// GetDashboardStats 获取大屏统计数据
func (ctrl *TraceController) GetDashboardStats(c *gin.Context) {
	var stats []model.DashboardStat
	if err := ctrl.DB.Order("stat_date DESC").Limit(15).Find(&stats).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "查询统计数据失败"})
		return
	}
	// 倒序为时间正序
	for i, j := 0, len(stats)-1; i < j; i, j = i+1, j-1 {
		stats[i], stats[j] = stats[j], stats[i]
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": stats})
}

// ==================== 批次管理 ====================

type CreateBatchRequest struct {
	ProductName string  `json:"product_name" binding:"required"`
	ProductType string  `json:"product_type" binding:"required"`
	Quantity    float64 `json:"quantity" binding:"required,gt=0"`
	Unit        string  `json:"unit" binding:"required"`
	OriginInfo  string  `json:"origin_info" binding:"required"`
}

func (ctrl *TraceController) CreateBatch(c *gin.Context) {
	var req CreateBatchRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "msg": err.Error()})
		return
	}
	farmerID, _ := c.Get("user_id")
	batchNo := fmt.Sprintf("BATCH-%s-%s", time.Now().Format("20060102"), uuid.New().String()[:8])
	traceCode := fmt.Sprintf("AKS%s%s", time.Now().Format("200601"), uuid.New().String()[:4])
	batch := model.AgriBatch{
		BatchNo: batchNo, TraceCode: traceCode,
		ProductName: req.ProductName, ProductType: req.ProductType,
		Quantity: req.Quantity, Unit: req.Unit,
		OriginInfo: req.OriginInfo, FarmerID: farmerID.(uint), Status: 0,
	}
	if err := ctrl.DB.Create(&batch).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "批次创建失败"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "msg": "批次创建成功",
		"data": gin.H{"batch_no": batchNo, "trace_code": traceCode, "batch_id": batch.ID}})
}

func (ctrl *TraceController) ListBatches(c *gin.Context) {
	var batches []model.AgriBatch
	query := ctrl.DB.Model(&model.AgriBatch{})
	role, _ := c.Get("role")
	if role == "farmer" {
		userID, _ := c.Get("user_id")
		query = query.Where("farmer_id = ?", userID)
	}
	if err := query.Order("created_at DESC").Find(&batches).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "查询失败"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": batches})
}

func (ctrl *TraceController) GetBatchDetail(c *gin.Context) {
	id := c.Param("id")
	var batch model.AgriBatch
	if err := ctrl.DB.First(&batch, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"code": 404, "msg": "批次不存在"})
		return
	}
	var records []model.TraceRecord
	ctrl.DB.Where("batch_id = ?", batch.ID).Order("operation_time ASC").Find(&records)
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": gin.H{"batch": batch, "records": records}})
}

// ==================== 溯源记录管理（通用） ====================

type AddTraceRecordRequest struct {
	BatchID       uint                   `json:"batch_id" binding:"required"`
	NodeType      string                 `json:"node_type" binding:"required"`
	OperationTime string                 `json:"operation_time" binding:"required"`
	Location      string                 `json:"location" binding:"required"`
	EnvData       map[string]interface{} `json:"env_data"`
}

func (ctrl *TraceController) AddTraceRecord(c *gin.Context) {
	var req AddTraceRecordRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "msg": err.Error()})
		return
	}
	var batch model.AgriBatch
	if err := ctrl.DB.First(&batch, req.BatchID).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"code": 404, "msg": "批次不存在"})
		return
	}
	opTime, err := time.Parse("2006-01-02 15:04:05", req.OperationTime)
	if err != nil {
		opTime = time.Now()
	}
	operatorID, _ := c.Get("user_id")
	payload := blockchain.TracePayload{
		BatchNo: batch.BatchNo, NodeType: req.NodeType,
		OperatorID: operatorID.(uint), OperationTime: opTime,
		Location: req.Location, EnvData: req.EnvData,
	}
	txResult, err := ctrl.BlockchainClient.SubmitTrace(payload)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "上链失败: " + err.Error()})
		return
	}
	record := model.TraceRecord{
		BatchID: req.BatchID, NodeType: req.NodeType,
		OperatorID: operatorID.(uint), OperationTime: opTime,
		Location: req.Location, EnvData: model.JSONMap(req.EnvData),
		TxHash: txResult.TxHash, BlockHeight: txResult.BlockHeight,
	}
	if err := ctrl.DB.Create(&record).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "记录保存失败"})
		return
	}
	statusMap := map[string]int8{
		"planting": 0, "harvesting": 1, "inspecting": 2,
		"packing": 2, "processing": 2, "transporting": 3, "retailing": 4,
	}
	if newStatus, ok := statusMap[req.NodeType]; ok {
		ctrl.DB.Model(&batch).Update("status", newStatus)
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "msg": "溯源记录添加成功",
		"data": gin.H{"record_id": record.ID, "tx_hash": txResult.TxHash,
			"block_height": txResult.BlockHeight, "is_mock": txResult.IsMock}})
}

// ListTraceRecords 通用溯源记录列表（按node_type过滤）
func (ctrl *TraceController) ListTraceRecords(c *gin.Context) {
	batchID := c.Query("batch_id")
	nodeType := c.Query("node_type")
	query := ctrl.DB.Model(&model.TraceRecord{})
	if batchID != "" {
		query = query.Where("batch_id = ?", batchID)
	}
	if nodeType != "" {
		query = query.Where("node_type = ?", nodeType)
	}
	var records []model.TraceRecord
	if err := query.Order("operation_time ASC").Find(&records).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "查询失败"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": records})
}

// ==================== 专用业务列表接口 ====================

// scanRows 通用行扫描工具（接受 *sql.Rows）
func scanRows(rows *sql.Rows) []map[string]interface{} {
	var list []map[string]interface{}
	cols, _ := rows.Columns()
	for rows.Next() {
		vals := make([]interface{}, len(cols))
		ptrs := make([]interface{}, len(cols))
		for i := range vals {
			ptrs[i] = &vals[i]
		}
		rows.Scan(ptrs...)
		m := make(map[string]interface{})
		for i, col := range cols {
			val := vals[i]
			if b, ok := val.([]byte); ok {
				m[col] = string(b)
			} else {
				m[col] = val
			}
		}
		list = append(list, m)
	}
	if list == nil {
		list = []map[string]interface{}{}
	}
	return list
}

// ListPlantingRecords 种植记录列表（直接查 planting_records 表）
func (ctrl *TraceController) ListPlantingRecords(c *gin.Context) {
	rows, err := ctrl.DB.Raw(`
		SELECT p.*, b.batch_no
		FROM planting_records p
		LEFT JOIN agri_batches b ON b.id = p.batch_id
		ORDER BY p.created_at DESC
	`).Rows()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "查询失败"})
		return
	}
	defer rows.Close()
	list := scanRows(rows)
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": list})
}

// ListProcessingRecords 加工记录列表
func (ctrl *TraceController) ListProcessingRecords(c *gin.Context) {
	rows, err := ctrl.DB.Raw(`
		SELECT p.*, b.batch_no, u.real_name as operator_name
		FROM processing_records p
		LEFT JOIN agri_batches b ON b.id = p.batch_id
		LEFT JOIN users u ON u.id = p.operator_id
		ORDER BY p.created_at DESC
	`).Rows()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "查询失败"})
		return
	}
	defer rows.Close()
	list := scanRows(rows)
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": list})
}

// ListInspectionRecords 质检记录列表
func (ctrl *TraceController) ListInspectionRecords(c *gin.Context) {
	rows, err := ctrl.DB.Raw(`
		SELECT i.*, b.batch_no, b.product_name, u.real_name as inspector_name
		FROM inspection_records i
		LEFT JOIN agri_batches b ON b.id = i.batch_id
		LEFT JOIN users u ON u.id = i.inspector_id
		ORDER BY i.created_at DESC
	`).Rows()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "查询失败"})
		return
	}
	defer rows.Close()
	list := scanRows(rows)
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": list})
}

// ListLogisticsRecords 物流记录列表
func (ctrl *TraceController) ListLogisticsRecords(c *gin.Context) {
	rows, err := ctrl.DB.Raw(`
		SELECT l.*, b.batch_no, b.product_name, u.real_name as operator_name
		FROM logistics_records l
		LEFT JOIN agri_batches b ON b.id = l.batch_id
		LEFT JOIN users u ON u.id = l.operator_id
		ORDER BY l.created_at DESC
	`).Rows()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "查询失败"})
		return
	}
	defer rows.Close()
	list := scanRows(rows)
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": list})
}

// ListCertificates 合格证列表
func (ctrl *TraceController) ListCertificates(c *gin.Context) {
	rows, err := ctrl.DB.Raw(`
		SELECT c.*, b.batch_no, b.trace_code, b.product_name
		FROM certificates c
		LEFT JOIN agri_batches b ON b.id = c.batch_id
		ORDER BY c.created_at DESC
	`).Rows()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "查询失败"})
		return
	}
	defer rows.Close()
	list := scanRows(rows)
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": list})
}

// ==================== 溯源查询与电子合格证 ====================

func (ctrl *TraceController) QueryByTraceCode(c *gin.Context) {
	code := c.Param("trace_code")
	var batch model.AgriBatch
	if err := ctrl.DB.Where("trace_code = ?", code).First(&batch).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"code": 404, "msg": "未找到该溯源码对应的产品信息"})
		return
	}
	today := time.Now().Format("2006-01-02")
	ctrl.DB.Exec("UPDATE dashboard_stats SET total_queries = total_queries + 1 WHERE stat_date = ?", today)

	var records []model.TraceRecord
	ctrl.DB.Where("batch_id = ?", batch.ID).Order("operation_time ASC").Find(&records)
	var cert model.Certificate
	ctrl.DB.Where("batch_id = ?", batch.ID).First(&cert)

	c.JSON(http.StatusOK, gin.H{"code": 200, "data": gin.H{
		"batch": batch, "records": records, "certificate": cert,
	}})
}

func (ctrl *TraceController) GetCertificate(c *gin.Context) {
	batchID := c.Param("batch_id")
	var cert model.Certificate
	if err := ctrl.DB.Where("batch_id = ?", batchID).First(&cert).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"code": 404, "msg": "该批次暂无电子合格证"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": cert})
}

func (ctrl *TraceController) GetBlockInfo(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"code": 200, "data": gin.H{
		"channel": "agrichannel", "height": 2156,
		"current_hash":  "0x8b3a4f9e2d1c5b7a6f8e9d0c1b2a3f4e5d6c7b8a9f0e1d2c3b4a5f6e7d8c9b0a",
		"previous_hash": "0x7a2b3e8d1c0f5a6b4c9d8e7f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b",
		"total_tx": 15890, "nodes": []string{
			"peer0.org1.example.com", "peer0.org2.example.com", "peer0.org3.example.com",
		},
		"consensus_type": "Raft", "crypto_type": "国密SM2/SM3",
	}})
}

func (ctrl *TraceController) UpdateBatch(c *gin.Context) {
	id := c.Param("id")
	var batch model.AgriBatch
	if err := ctrl.DB.First(&batch, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"code": 404, "msg": "批次不存在"})
		return
	}
	var updates map[string]interface{}
	if err := c.ShouldBindJSON(&updates); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"code": 400, "msg": err.Error()})
		return
	}
	delete(updates, "batch_no")
	delete(updates, "trace_code")
	if err := ctrl.DB.Model(&batch).Updates(updates).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "更新失败"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "msg": "更新成功"})
}

func (ctrl *TraceController) DeleteBatch(c *gin.Context) {
	id := c.Param("id")
	if err := ctrl.DB.Delete(&model.AgriBatch{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "删除失败"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"code": 200, "msg": "删除成功"})
}
