package utils

import (
	"agri-trace/config"
	"agri-trace/model"
	"log"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// InitDB 初始化数据库连接，并自动同步所有表结构
func InitDB(cfg *config.DatabaseConfig) *gorm.DB {
	db, err := gorm.Open(mysql.Open(cfg.DSN), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Info),
	})
	if err != nil {
		log.Fatalf("[DB] 数据库连接失败: %v", err)
	}

	// 自动迁移：GORM 管理的模型表（不会删除已有数据，只会新增列）
	if err := db.AutoMigrate(
		&model.User{},
		&model.Captcha{},
		&model.AgriBatch{},
		&model.TraceRecord{},
		&model.Certificate{},
		&model.DashboardStat{},
	); err != nil {
		log.Printf("[DB] GORM 表结构迁移警告: %v", err)
	}

	// 手动建表：专用业务表（不在 GORM 模型中，通过原生 SQL 管理）
	createSpecializedTables(db)

	log.Println("[DB] 数据库连接成功，表结构已同步")
	return db
}

// createSpecializedTables 创建专用业务表（IF NOT EXISTS，不影响已有数据）
func createSpecializedTables(db *gorm.DB) {
	sqls := []string{
		// 种植记录表
		`CREATE TABLE IF NOT EXISTS planting_records (
			id              BIGINT        NOT NULL AUTO_INCREMENT,
			batch_id        BIGINT        NOT NULL COMMENT '关联批次ID',
			farmer_id       BIGINT        NOT NULL COMMENT '种植户ID',
			field_name      VARCHAR(128)  NOT NULL COMMENT '地块名称',
			field_area      DECIMAL(10,2) DEFAULT NULL COMMENT '种植面积(亩)',
			field_lat       DECIMAL(10,7) DEFAULT NULL,
			field_lng       DECIMAL(10,7) DEFAULT NULL,
			plant_date      DATE          NOT NULL COMMENT '种植日期',
			expected_harvest DATE         DEFAULT NULL COMMENT '预计采收日期',
			seed_variety    VARCHAR(64)   DEFAULT NULL COMMENT '种苗品种',
			seed_source     VARCHAR(128)  DEFAULT NULL COMMENT '种苗来源',
			fertilizer_type VARCHAR(128)  DEFAULT NULL COMMENT '施肥类型',
			fertilizer_date DATE          DEFAULT NULL COMMENT '最近施肥日期',
			irrigation_type VARCHAR(64)   DEFAULT NULL COMMENT '灌溉方式',
			irrigation_date DATE          DEFAULT NULL COMMENT '最近灌溉日期',
			pesticide_type  VARCHAR(128)  DEFAULT NULL COMMENT '农药类型',
			weeding_date    DATE          DEFAULT NULL COMMENT '最近除草日期',
			soil_ph         VARCHAR(16)   DEFAULT NULL COMMENT '土壤pH值',
			temperature     VARCHAR(16)   DEFAULT NULL COMMENT '环境温度',
			humidity        VARCHAR(16)   DEFAULT NULL COMMENT '环境湿度',
			images          JSON          DEFAULT NULL COMMENT '现场图片URL列表',
			tx_hash         VARCHAR(128)  DEFAULT NULL COMMENT '区块链交易哈希',
			block_height    BIGINT        DEFAULT NULL COMMENT '区块高度',
			created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY idx_planting_batch_id (batch_id),
			KEY idx_planting_farmer_id (farmer_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='种植记录表'`,

		// 采收记录表
		`CREATE TABLE IF NOT EXISTS harvest_records (
			id              BIGINT        NOT NULL AUTO_INCREMENT,
			batch_id        BIGINT        NOT NULL,
			operator_id     BIGINT        NOT NULL COMMENT '操作人ID',
			harvest_date    DATETIME      NOT NULL COMMENT '采收时间',
			harvest_method  VARCHAR(64)   DEFAULT NULL COMMENT '采收方式',
			actual_quantity DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '实际采收量(kg)',
			weather         VARCHAR(32)   DEFAULT NULL COMMENT '天气情况',
			sugar_content   VARCHAR(16)   DEFAULT NULL COMMENT '糖度(%)',
			hardness        VARCHAR(16)   DEFAULT NULL COMMENT '硬度',
			location        VARCHAR(255)  NOT NULL DEFAULT '' COMMENT '采收地点',
			lat             DECIMAL(10,7) DEFAULT NULL,
			lng             DECIMAL(10,7) DEFAULT NULL,
			images          JSON          DEFAULT NULL,
			tx_hash         VARCHAR(128)  DEFAULT NULL,
			block_height    BIGINT        DEFAULT NULL,
			created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY idx_harvest_batch_id (batch_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='采收记录表'`,

		// 加工记录表
		`CREATE TABLE IF NOT EXISTS processing_records (
			id               BIGINT        NOT NULL AUTO_INCREMENT,
			batch_id         BIGINT        NOT NULL,
			operator_id      BIGINT        NOT NULL COMMENT '操作人ID',
			operator_phone   VARCHAR(20)   DEFAULT NULL COMMENT '操作人电话',
			process_type     VARCHAR(64)   NOT NULL DEFAULT '' COMMENT '加工类型',
			process_time     DATETIME      NOT NULL COMMENT '加工时间',
			facility_name    VARCHAR(128)  NOT NULL DEFAULT '' COMMENT '加工设施名称',
			facility_addr    VARCHAR(255)  DEFAULT NULL COMMENT '设施地址',
			facility_lat     DECIMAL(10,7) DEFAULT NULL,
			facility_lng     DECIMAL(10,7) DEFAULT NULL,
			input_quantity   DECIMAL(10,2) DEFAULT NULL COMMENT '投入量(kg)',
			output_quantity  DECIMAL(10,2) DEFAULT NULL COMMENT '产出量(kg)',
			pack_spec        VARCHAR(64)   DEFAULT NULL COMMENT '包装规格',
			pack_material    VARCHAR(64)   DEFAULT NULL COMMENT '包装材料',
			total_boxes      INT           DEFAULT NULL COMMENT '总箱数',
			standard_no      VARCHAR(64)   DEFAULT NULL COMMENT '执行标准编号',
			images           JSON          DEFAULT NULL,
			tx_hash          VARCHAR(128)  DEFAULT NULL,
			block_height     BIGINT        DEFAULT NULL,
			created_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY idx_processing_batch_id (batch_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='加工记录表'`,

		// 质检记录表
		`CREATE TABLE IF NOT EXISTS inspection_records (
			id                  BIGINT       NOT NULL AUTO_INCREMENT,
			batch_id            BIGINT       NOT NULL,
			inspector_id        BIGINT       NOT NULL COMMENT '质检员ID',
			inspect_time        DATETIME     NOT NULL COMMENT '质检时间',
			inspect_org         VARCHAR(128) NOT NULL DEFAULT '' COMMENT '质检机构',
			inspect_addr        VARCHAR(255) DEFAULT NULL COMMENT '质检地址',
			cert_no             VARCHAR(64)  DEFAULT NULL COMMENT '检验报告编号',
			pesticide_result    VARCHAR(16)  NOT NULL DEFAULT '合格' COMMENT '农药残留检测',
			heavy_metal_result  VARCHAR(16)  NOT NULL DEFAULT '合格' COMMENT '重金属检测',
			microbe_result      VARCHAR(16)  NOT NULL DEFAULT '合格' COMMENT '微生物检测',
			appearance_grade    VARCHAR(16)  DEFAULT NULL COMMENT '外观等级',
			overall_result      VARCHAR(16)  NOT NULL DEFAULT '合格' COMMENT '综合结论',
			report_url          VARCHAR(512) DEFAULT NULL COMMENT '检测报告文件URL',
			images              JSON         DEFAULT NULL,
			tx_hash             VARCHAR(128) DEFAULT NULL,
			block_height        BIGINT       DEFAULT NULL,
			created_at          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY idx_inspection_batch_id (batch_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='质检记录表'`,

		// 物流追踪表
		`CREATE TABLE IF NOT EXISTS logistics_records (
			id               BIGINT        NOT NULL AUTO_INCREMENT,
			batch_id         BIGINT        NOT NULL,
			operator_id      BIGINT        NOT NULL COMMENT '物流操作人ID',
			transport_type   VARCHAR(32)   NOT NULL DEFAULT '' COMMENT '运输方式',
			vehicle_no       VARCHAR(32)   DEFAULT NULL COMMENT '车牌号/运单号',
			driver_name      VARCHAR(32)   DEFAULT NULL COMMENT '司机姓名',
			driver_phone     VARCHAR(20)   DEFAULT NULL COMMENT '司机电话',
			depart_time      DATETIME      NOT NULL COMMENT '发车时间',
			arrive_time      DATETIME      DEFAULT NULL COMMENT '到达时间',
			depart_location  VARCHAR(255)  NOT NULL DEFAULT '' COMMENT '出发地',
			depart_lat       DECIMAL(10,7) DEFAULT NULL,
			depart_lng       DECIMAL(10,7) DEFAULT NULL,
			arrive_location  VARCHAR(255)  NOT NULL DEFAULT '' COMMENT '目的地',
			arrive_lat       DECIMAL(10,7) DEFAULT NULL,
			arrive_lng       DECIMAL(10,7) DEFAULT NULL,
			temp_control     VARCHAR(32)   DEFAULT NULL COMMENT '温控要求',
			current_temp     VARCHAR(16)   DEFAULT NULL COMMENT '实时温度',
			status           VARCHAR(16)   NOT NULL DEFAULT 'in_transit' COMMENT '状态',
			images           JSON          DEFAULT NULL,
			tx_hash          VARCHAR(128)  DEFAULT NULL,
			block_height     BIGINT        DEFAULT NULL,
			created_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY idx_logistics_batch_id (batch_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='物流追踪表'`,

		// IPFS文件关联表
		`CREATE TABLE IF NOT EXISTS ipfs_files (
			id          BIGINT       NOT NULL AUTO_INCREMENT,
			record_id   BIGINT       NOT NULL COMMENT '关联记录ID',
			record_type VARCHAR(32)  NOT NULL DEFAULT 'trace' COMMENT '记录类型',
			file_name   VARCHAR(128) NOT NULL DEFAULT '',
			file_type   VARCHAR(32)  NOT NULL DEFAULT '' COMMENT '文件类型',
			cid         VARCHAR(128) NOT NULL DEFAULT '' COMMENT 'IPFS CID',
			file_url    VARCHAR(512) DEFAULT NULL COMMENT '可访问URL',
			created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY idx_ipfs_record_id (record_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='IPFS文件关联表'`,

		// 操作日志表
		`CREATE TABLE IF NOT EXISTS operation_logs (
			id         BIGINT       NOT NULL AUTO_INCREMENT,
			user_id    BIGINT       DEFAULT NULL COMMENT '操作用户ID',
			username   VARCHAR(64)  DEFAULT NULL,
			action     VARCHAR(64)  NOT NULL DEFAULT '' COMMENT '操作动作',
			module     VARCHAR(32)  NOT NULL DEFAULT '' COMMENT '模块',
			target_id  BIGINT       DEFAULT NULL COMMENT '操作对象ID',
			detail     VARCHAR(512) DEFAULT NULL COMMENT '操作详情',
			ip         VARCHAR(64)  DEFAULT NULL COMMENT '客户端IP',
			user_agent VARCHAR(256) DEFAULT NULL,
			status     VARCHAR(16)  NOT NULL DEFAULT 'success' COMMENT '结果',
			created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY idx_log_user_id (user_id),
			KEY idx_log_created_at (created_at)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表'`,
	}

	for _, sql := range sqls {
		if err := db.Exec(sql).Error; err != nil {
			log.Printf("[DB] 建表警告: %v", err)
		}
	}
	log.Println("[DB] 专用业务表检查完成（IF NOT EXISTS）")
}
